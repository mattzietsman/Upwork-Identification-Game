package com.example.b_cognitivekids_memorygame_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
